## Vindico app setup Laravel PHP Framework

this scafold project based on [PHP OAuth 2.0 Server for Laravel] (https://github.com/lucadegasperi/oauth2-server-laravel)



 
