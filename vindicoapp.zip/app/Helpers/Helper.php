<?php // Code within app\Helpers\Helper.php

    namespace App\Helpers;

    class Helper
    {
        public static function checkDataExist($data)
        {
            return null !==$data ? true : false;
        }

       
    }